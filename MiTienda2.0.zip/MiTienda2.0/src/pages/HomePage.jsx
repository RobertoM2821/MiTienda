import React, { useState } from 'react';
import Modal from '../components/Modal';


const formStyles = {
  display: 'flex',
  flexDirection: 'column',
  gap: '1rem',
};
const inputStyles = {
  padding: '10px',
  borderRadius: '8px',
  border: '1px solid var(--color-border-light)',
  fontSize: '1em',
};
const textareaStyles = {
  ...inputStyles,
  minHeight: '100px',
  resize: 'vertical',
};
const submitButtonStyles = {
  backgroundColor: 'var(--color-accent-mint)',
};

function HomePage() {
 
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleDonationSubmit = (event) => {
    event.preventDefault();
    alert('¡Gracias por tu donación! Hemos recibido la información.');
    setIsModalOpen(false); 
  };

  return (
    <div style={{ textAlign: 'center', padding: '50px 20px' }}>
      <h1>Bienvenido a Nuestra Tienda</h1>
      <p style={{ color: 'var(--color-text-light)', fontSize: '1.1em', maxWidth: '600px', margin: '1rem auto 2rem' }}>
        Descubre prendas únicas, dona con propósito y dale una nueva vida a tu estilo.
      </p>

      {/* Botón de Donación */}
      <button 
        style={{ backgroundColor: 'var(--color-accent-peach)', fontSize: '1.1em' }} 
        onClick={() => setIsModalOpen(true)}
      >
        Donar Ropa
      </button>

      {/* Modal de Donación */}
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)}>
        <h2 style={{ marginBottom: '1.5rem', textAlign: 'center' }}>Formulario de Donación</h2>
        <form onSubmit={handleDonationSubmit} style={formStyles}>
          <label htmlFor="clothes-images">Sube fotos de la ropa (puedes seleccionar varias):</label>
          <input 
            type="file" 
            id="clothes-images" 
            accept="image/*" 
            multiple 
            required
            style={inputStyles} 
          />
          
          <label htmlFor="description">Descripción (estado, tallas, etc.):</label>
          <textarea 
            id="description" 
            placeholder="Ej: Camisa de algodón talla M en buen estado, pantalón de mezclilla..." 
            required
            style={textareaStyles}
          ></textarea>
          
          <button type="submit" style={submitButtonStyles}>
            Enviar Donación
          </button>
        </form>
      </Modal>

      <div style={{ marginTop: '3rem' }}>
        
      </div>
    </div>
  );
}

export default HomePage;