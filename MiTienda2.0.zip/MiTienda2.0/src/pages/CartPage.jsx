import React, { useContext } from 'react';
import { CartContext } from '../context/CartContext';
import { Link } from 'react-router-dom';
import './CartPage.css';

function CartPage() {
  const { cart, removeFromCart } = useContext(CartContext);
  if (cart.length === 0) {
    return (
      <div className="empty-cart">
        <h1>Tu carrito está vacío</h1>
        <Link to="/products" className="explore-products-link">Explorar productos</Link>
      </div>
    );
  }
  const totalPrice = cart.reduce((total, item) => total + item.price * item.quantity, 0);
  return (
    <div className="cart-page">
      <h1 className="cart-page-title">Tu Carrito</h1>
      <div>
        {cart.map(item => (
          <div key={item.id} className="cart-item">
            <img src={item.image} alt={item.title} className="cart-item-image" />
            <div className="cart-item-info">
              <p className="cart-item-title">{item.title}</p>
              <p className="cart-item-quantity">Cantidad: {item.quantity}</p>
            </div>
            <p className="cart-item-total-price">${(item.price * item.quantity).toFixed(2)}</p>
            <button className="remove-button" onClick={() => removeFromCart(item.id)}>Eliminar</button>
          </div>
        ))}
      </div>
      <h2 className="cart-total">Total: ${totalPrice.toFixed(2)}</h2>
    </div>
  );
}

export default CartPage;