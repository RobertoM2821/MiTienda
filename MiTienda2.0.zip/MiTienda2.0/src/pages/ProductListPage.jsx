import React, { useState, useEffect } from 'react';
import ProductCard from './ProductCard';
import { Link } from 'react-router-dom';

const productGridStyles = {
  display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
  gap: '1.5rem', padding: '1.5rem 0'
};

function ProductListPage() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  useEffect(() => {
    fetch('https://fakestoreapi.com/products')
      .then(res => res.ok ? res.json() : Promise.reject('Error al cargar productos'))
      .then(data => { setProducts(data); setLoading(false); })
      .catch(err => { setError(err.toString()); setLoading(false); });
  }, []);

  if (loading) return <p className="message-center">Cargando productos...</p>;
  if (error) return <p className="message-center error">Error: {error}</p>;

  return (
    <div>
      <h1 style={{textAlign: 'center', marginBottom: '1.5rem'}}>Nuestros Productos</h1>
      <div style={productGridStyles}>
        {products.map(product => (
          <Link to={`/product/${product.id}`} key={product.id} style={{ textDecoration: 'none', color: 'inherit' }}>
            <ProductCard product={product} />
          </Link>
        ))}
      </div>
    </div>
  );
}
export default ProductListPage;