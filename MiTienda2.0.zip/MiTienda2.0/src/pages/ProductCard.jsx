import React from 'react';
import './ProductCard.css';

function ProductCard({ product }) {
  return (
    <div className="product-card">
      <img src={product.image} alt={product.title} className="product-card-image" />
      <h3 className="product-card-title">{product.title}</h3>
      <p className="product-card-price">${product.price.toFixed(2)}</p>
    </div>
  );
}
export default ProductCard;