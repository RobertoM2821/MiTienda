import React, { useState, useEffect, useContext } from 'react';
import { useParams } from 'react-router-dom';
import { CartContext } from '../context/CartContext';
import './ProductDetailPage.css';

function ProductDetailPage() {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const { addToCart } = useContext(CartContext);
  useEffect(() => {
    fetch(`https://fakestoreapi.com/products/${id}`)
      .then(res => res.ok ? res.json() : Promise.reject('Error al cargar el producto'))
      .then(data => { setProduct(data); setLoading(false); })
      .catch(err => { setError(err.toString()); setLoading(false); });
  }, [id]);

  if (loading) return <p className="message-center">Cargando detalles...</p>;
  if (error) return <p className="message-center error">{error}</p>;
  if (!product) return <p className="message-center">Producto no encontrado.</p>;

  return (
    <div className="detail-container">
      <h1 className="detail-title">{product.title}</h1>
      <div className="product-content">
        <div className="image-wrapper"><img src={product.image} alt={product.title} className="detail-image" /></div>
        <div className="info-wrapper">
          <p className="detail-price">${product.price.toFixed(2)}</p>
          <p className="detail-description">{product.description}</p>
          <button className="add-to-cart-button" onClick={() => addToCart(product)}>Añadir al carrito</button>
        </div>
      </div>
    </div>
  );
}

export default ProductDetailPage;