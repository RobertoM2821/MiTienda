import React, { useState, useContext } from 'react';
import { NavLink, Link } from 'react-router-dom';
import { CartContext } from '../context/CartContext';
import './NavBar.css';

function NavBar() {
  const [menuOpen, setMenuOpen] = useState(false);
  const { cart } = useContext(CartContext);
  const totalItems = cart.reduce((total, item) => total + item.quantity, 0);
  return (
    <nav className="navbar">
      <NavLink to="/" className="navbar-logo" onClick={() => setMenuOpen(false)}>MiTienda</NavLink>
      <div className="menu-icon" onClick={() => setMenuOpen(!menuOpen)}>☰</div>
      <div className={`nav-links ${menuOpen ? 'active' : ''}`}>
        <NavLink to="/" onClick={() => setMenuOpen(false)}>Inicio</NavLink>
        <NavLink to="/products" onClick={() => setMenuOpen(false)}>Productos</NavLink>
        <Link to="/cart" className="cart-link" onClick={() => setMenuOpen(false)}>
          Carrito {totalItems > 0 && <span className="cart-count">{totalItems}</span>}
        </Link>
      </div>
    </nav>
  );
}

export default NavBar;